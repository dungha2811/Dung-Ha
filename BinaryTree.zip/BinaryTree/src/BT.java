public class BT {
    Node root;

    public void InOrder(Node curr){
        if(curr!= null){
            InOrder(curr.left);
            System.out.println(" "+ curr.val);
            InOrder(curr.right);
        }
    }

    public void PreOrder(Node curr){
        if(curr!=null){
            System.out.println(" "+ curr.val);
            InOrder(curr.left);
            InOrder(curr.right);
        }
    }
    public void PostOrder(Node curr){
        if(curr!= null){
            InOrder(curr.left);
            InOrder(curr.right);
            System.out.println(" "+ curr.val);
        }
    }
}
