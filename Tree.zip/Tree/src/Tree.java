public class Tree {
    Node root;

    public void add(int val){

        //if it is the first root
        if(root == null){
            root = new Node(val);
        }
        else if(root.left == null){
            root.left = new Node(val);
        }
    }

}
