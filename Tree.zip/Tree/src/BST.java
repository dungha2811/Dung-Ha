public class BST {
    Node root;

    public Node addSub(Node curr,int val){

        //if it is the first root
        if(curr == null){
            return new Node(val);
        }

        //if the added value is less than it own root then bring it to the left
        if(val < curr.val){
            curr.left = addSub(curr.left,val);
        }
        //if the added value is laeger than it own root then bring it to the right
        else if(val > curr.val){
            curr.right = addSub(curr.right,val);
        }

        //duplicate value cases
        else{
            return curr;
        }

        //return the current node
        return curr;
    }

    public void add(int val){
        root = addSub(root,val);
    }

    public void inOrder(Node curr){

        //if current root is not null
        if(curr != null){

            //recursive call with the left node of the current root
            inOrder(curr.left);

            //print out the tree value
            System.out.print(" "+ curr.val);

            //recursive call with
            inOrder(curr.right);
        }

    }
}
