import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;


public class MainShuffle {
    public static void main(String args[]) throws IOException {
        //create ArrayList of student object
        ArrayList<Student> array = new ArrayList<Student>();
        ArrayList<Student> shuffleArray = new ArrayList<Student>();
        //read the file
        File file = new File("student.txt");
        Scanner inputFile = new Scanner(file);

        //read in file and add to arrayList
        while(inputFile.hasNextLine()){
            String input = inputFile.nextLine();
            int mainID= Integer.parseInt(input.split(",")[0]);
            String mainStu = input.split(",")[1];
            String mainGender = input.split(",")[2];
            Boolean mainInter = Boolean.parseBoolean(input.split(",")[3]);
            array.add(new Student(mainID,mainStu,mainGender,mainInter));

        }
        Collections.shuffle(array);
        int totalStudent =30;
        int team = 10;
        int studentInTeam = totalStudent/team;
        int count =0;
        int teamCount=0;
        for(int i =0;i<array.size();i++){
            if(count==studentInTeam||i==0){
                count=0;
                teamCount++;
                System.out.println("\nTeam"+ (teamCount));
            }
            System.out.println(array.get(i).getName());
            count++;
        }
        inputFile.close();
    }
}
