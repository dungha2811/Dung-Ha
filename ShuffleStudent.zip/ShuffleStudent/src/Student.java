public class Student {
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private int id;
    private String name;
    private String gender;
    private boolean inter;

    public Student(int id,String name, String gender, boolean inter) {
        this.name = name;
        this.gender = gender;
        this.inter = inter;
        this.id = id;
    }

    public Student() {
        name=null;
        gender=null;
        inter=false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isInter() {
        return inter;
    }

    public void setInter(boolean inter) {
        this.inter = inter;
    }
}
